#include <stdio.h>
main()
{
   printf("%s\n%s\n", "Linux", "C Programming");
}
