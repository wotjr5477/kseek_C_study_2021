/* hi.c */
#include <stdio.h>
void hi()
{
   printf("Hi\n");
}
