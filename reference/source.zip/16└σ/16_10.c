#include <stdio.h>
main()
{
   printf("debugging"); 
}