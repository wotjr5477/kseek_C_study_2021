#include <stdio.h>
#include "myheader.h"
main()
{
   printf("%d\n", AGE);
}