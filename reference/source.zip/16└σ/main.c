/* main.c */
extern void hi();
main()
{
   hi();
}