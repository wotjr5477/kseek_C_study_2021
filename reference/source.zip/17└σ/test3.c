#include "b.h"
#include "c.h"
extern void func2()
{
   printf("test3\n");
}