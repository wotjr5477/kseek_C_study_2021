#include "a.h"
#include "b.h"
extern void func1()
{
   printf("test2\n");
}