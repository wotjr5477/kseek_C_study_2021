#include "a.h"
void func1();
void func2();
main()
{
   printf("test1\n");
   func1();
   func2();
}