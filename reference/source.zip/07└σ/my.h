#define A 5
#define B 10
#define C 20