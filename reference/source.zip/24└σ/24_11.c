#include <stdio.h>
#include <unistd.h>

main() 
{ 
    /* ���� �ݺ� */
    while(1) {
       printf("running\n");
       sleep(5);
    }
}